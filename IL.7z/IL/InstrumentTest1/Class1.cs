public class Class1
{
    public static void Call()
    {
        Console.WriteLine("Form Class1.");
    }
}