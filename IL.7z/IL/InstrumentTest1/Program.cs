﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;

Stopwatch sw = new Stopwatch();
sw.Start();

Console.WriteLine("From Main.");
Class1.Call();



sw.Stop();
Console.WriteLine(sw.Elapsed);

Console.Read();